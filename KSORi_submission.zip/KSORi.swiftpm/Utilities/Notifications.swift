import Foundation

extension Notification.Name {
    static let appStopAllAudio = Notification.Name("appStopAllAudio")
}
